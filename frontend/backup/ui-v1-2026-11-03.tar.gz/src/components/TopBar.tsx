import { Link } from 'react-router-dom'
import type { RoomService } from '../rooms/roomService'
import { useRoomInfo } from '../rooms/useRoomInfo'
import { ThemeToggle } from './ThemeToggle'

export function TopBar({ roomService }: { roomService?: RoomService }) {
  const { roomName, playerCount, leave } = useRoomInfo(roomService)
  return (
    <header className="topbar">
      <Link className="brand" to="/">
        ◆ Matelda
      </Link>
      <span className="topbar-end">
      {roomName ? (
        <>
          <span className="room">
            Room {roomName} · {playerCount} {playerCount === 1 ? 'player' : 'players'}
          </span>
          <button type="button" className="room-action" onClick={() => void leave()}>
            Leave room
          </button>
        </>
      ) : (
        <Link className="room" to="/lobby">
          Join a room
        </Link>
      )}
      <ThemeToggle />
      </span>
    </header>
  )
}

import { useEffect, useId, useRef, useState } from 'react'
import type { ButtonHTMLAttributes, ReactNode } from 'react'

export function Card({ title, children }: { title?: string; children: ReactNode }) {
  return (
    <section className="card">
      {title && <h2 className="card-title">{title}</h2>}
      {children}
    </section>
  )
}

/**
 * `loading` is for a button whose click starts something that takes a while: it is disabled and a spinner
 * replaces the label (the label stays in place, invisible, so the button keeps its width and its name).
 */
export function Button({
  variant = 'primary',
  className = '',
  loading = false,
  disabled,
  children,
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'ghost'; loading?: boolean }) {
  return (
    <button
      className={`btn btn-${variant}${loading ? ' is-loading' : ''} ${className}`.trim()}
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      {...rest}
    >
      {loading ? (
        <>
          <span className="btn-label">{children}</span>
          <span className="btn-spinner" aria-hidden="true">
            <span className="spinner" />
          </span>
        </>
      ) : (
        children
      )}
    </button>
  )
}

export function Notice({ kind, children }: { kind: 'info' | 'warn' | 'error'; children: ReactNode }) {
  return (
    <div className={`notice notice-${kind}`} role={kind === 'info' ? undefined : 'alert'}>
      {children}
    </div>
  )
}

export function JobStatus({
  state,
  error,
}: {
  state: 'idle' | 'running' | 'done' | 'failed' | 'lost'
  error?: string
}) {
  // While it runs, the button that started it shows the spinner (Button `loading`); nothing else does.
  if (state === 'failed') return <Notice kind="error">Failed: {error}</Notice>
  if (state === 'lost') return <Notice kind="warn">Job lost (the API restarted?). Run it again.</Notice>
  return null
}

/** The one loading indicator: a spinner with a short label. Use it everywhere something is on its way. */
export function Loading({ children, className = '' }: { children: ReactNode; className?: string }) {
  return (
    <p className={`loading ${className}`.trim()} role="status">
      <span className="spinner" aria-hidden="true" />
      {children}
    </p>
  )
}

/** A small "i" button that opens a popover with help text; closes on Escape or an outside click. */
export function InfoButton({ label = 'More info', children }: { label?: string; children: ReactNode }) {
  const [open, setOpen] = useState(false)
  const root = useRef<HTMLSpanElement>(null)
  const id = useId()
  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false)
    const onDown = (e: MouseEvent) => {
      if (root.current && !root.current.contains(e.target as Node)) setOpen(false)
    }
    document.addEventListener('keydown', onKey)
    document.addEventListener('mousedown', onDown)
    return () => {
      document.removeEventListener('keydown', onKey)
      document.removeEventListener('mousedown', onDown)
    }
  }, [open])
  return (
    <span className="info" ref={root}>
      <button
        type="button"
        className="info-btn"
        aria-label={label}
        aria-expanded={open}
        aria-controls={id}
        onClick={() => setOpen(!open)}
      >
        i
      </button>
      {open && (
        <div className="info-pop" id={id} role="note">
          {children}
        </div>
      )}
    </span>
  )
}

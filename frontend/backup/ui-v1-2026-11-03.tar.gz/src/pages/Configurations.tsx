import { useQuery } from '@tanstack/react-query'
import { useEffect, useRef, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { BudgetField, StrategyChecklist } from '../components/forms'
import { TableModal } from '../components/TableModal'
import '../styles/pages/configurations.css'
import { Button, Loading, Notice } from '../components/ui'
import { clampBudget, ensureSuffix, savePipelineChoice } from '../configurations/pipelineFlow'
import {
  copyPipeline,
  createPipeline,
  fetchDatasets,
  fetchPipeline,
  fetchPipelines,
  fetchStrategies,
  fetchTables,
  suggestPipelineName,
  updatePipeline,
} from '../lib/api'
import { useSession } from '../session/SessionProvider'

const DbIcon = () => (
  <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <ellipse cx="12" cy="5.5" rx="7.5" ry="3" />
    <path d="M4.5 5.5v6.5c0 1.66 3.36 3 7.5 3s7.5-1.34 7.5-3V5.5M4.5 12v6.5c0 1.66 3.36 3 7.5 3s7.5-1.34 7.5-3V12" />
  </svg>
)
const CheckIcon = () => (
  <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="m5 12.5 4.5 4.5L19 7.5" />
  </svg>
)
const TableIcon = () => (
  <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <rect x="3.5" y="4.5" width="17" height="15" rx="2.5" />
    <path d="M3.5 10h17M10 10v9.5" />
  </svg>
)

function Section({ title, hint, children }: { title: string; hint?: string; children: React.ReactNode }) {
  return (
    <section className="cfg-section">
      <header className="cfg-head">
        <h2>{title}</h2>
        {hint && <p>{hint}</p>}
      </header>
      <div className="cfg-body">{children}</div>
    </section>
  )
}

export function Configurations() {
  const session = useSession()
  const navigate = useNavigate()
  const suffix = session.sid.slice(0, 6)

  const [mode, setMode] = useState<'new' | 'existing'>('new')
  const [dataset, setDataset] = useState('')
  const [budget, setBudget] = useState(10)
  const [chosen, setChosen] = useState<string[] | null>(null) // null = all strategies
  const [typedName, setTypedName] = useState<string | null>(null)
  const [existing, setExisting] = useState('')
  const [saveAs, setSaveAs] = useState('')
  const [error, setError] = useState('')
  const [saving, setSaving] = useState(false)
  const [openTable, setOpenTable] = useState<string | null>(null)

  // Coming back from a later step: keep the settings you had, but stay on "Create new pipeline" (the default).
  const restored = useRef(false)
  useEffect(() => {
    if (!session.ready || restored.current) return
    restored.current = true
    const d = session.data
    if (typeof d.pipeline_path !== 'string' || !d.pipeline_path) return
    if (typeof d.dataset_select === 'string') setDataset(d.dataset_select)
    if (d.labeling_budget !== undefined) setBudget(clampBudget(d.labeling_budget))
    if (Array.isArray(d.selected_strategies)) setChosen(d.selected_strategies as string[])
  }, [session.ready, session.data])

  const datasets = useQuery({ queryKey: ['datasets'], queryFn: fetchDatasets })
  const strategies = useQuery({ queryKey: ['strategies'], queryFn: fetchStrategies })
  const pipelines = useQuery({ queryKey: ['pipelines'], queryFn: fetchPipelines })

  const sessionDataset = session.data.dataset_select as string | undefined
  const activeDataset = dataset || sessionDataset || datasets.data?.[0] || ''
  const tables = useQuery({
    queryKey: ['tables', activeDataset],
    queryFn: () => fetchTables(activeDataset),
    enabled: !!activeDataset,
  })
  const suggestion = useQuery({
    queryKey: ['suggest', activeDataset, suffix],
    queryFn: () => suggestPipelineName(activeDataset, suffix),
    enabled: mode === 'new' && !!activeDataset && !!suffix,
  })

  const selected = chosen ?? strategies.data ?? []
  const name = typedName ?? suggestion.data ?? ''
  const nameTaken =
    mode === 'new' && !!name && (pipelines.data ?? []).includes(ensureSuffix(name, suffix))

  const setBudgetFrom = (value: unknown) => setBudget(clampBudget(value))

  const chooseExisting = async (pipeline: string) => {
    setExisting(pipeline)
    setSaveAs('')
    if (!pipeline) return
    try {
      const cfg = await fetchPipeline(pipeline)
      setDataset(cfg.selected_dataset)
      setBudgetFrom(cfg.labeling_budget)
      setChosen(cfg.selected_strategies)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not load the pipeline')
    }
  }

  const blockers: string[] = []
  if (strategies.isError) blockers.push('strategies')
  if (selected.length === 0 && !strategies.isError) blockers.push('strategies')
  if (!activeDataset) blockers.push('Pick a dataset.')
  if (mode === 'new' && (!name || nameTaken)) blockers.push('name')
  if (mode === 'existing' && !existing) blockers.push('Select an existing pipeline.')
  const canSave = blockers.length === 0 && !saving

  const save = async () => {
    setSaving(true)
    setError('')
    try {
      const config = {
        selected_dataset: activeDataset,
        labeling_budget: budget,
        selected_strategies: selected,
      }
      const finalName = await savePipelineChoice({
        mode,
        name: mode === 'new' ? name : saveAs,
        originalName: mode === 'existing' ? existing : undefined,
        suffix,
        config,
        api: { createPipeline, updatePipeline, copyPipeline },
      })
      if (mode === 'new') await session.clear() // fresh pipeline starts without old folds
      await session.update({
        pipeline_path: finalName,
        dataset_select: activeDataset,
        labeling_budget: budget,
        selected_strategies: selected,
      })
      navigate('/domain-folding')
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not save the pipeline')
      setSaving(false)
    }
  }

  const datasetList = datasets.data ?? []
  const blockerText = !activeDataset
    ? 'Pick a dataset to continue.'
    : mode === 'existing' && !existing
      ? 'Select an existing pipeline to continue.'
      : selected.length === 0 && !strategies.isError
        ? 'Pick at least one detection strategy.'
        : nameTaken
          ? 'Choose a different pipeline name.'
          : mode === 'new' && !name
            ? 'Give the pipeline a name.'
            : ''

  return (
    <div className="config-page">
      <h1>Configurations</h1>
      <p className="cfg-lead">Set up the pipeline once; everyone in the room labels against it.</p>

      <Section title="Pipeline" hint="Start fresh or build on a pipeline you already saved.">
        <div className="cfg-segment" role="group" aria-label="Pipeline mode">
          <label className={mode === 'new' ? 'on' : ''}>
            <input type="radio" name="mode" checked={mode === 'new'} onChange={() => setMode('new')} />
            Create new pipeline
          </label>
          <label className={mode === 'existing' ? 'on' : ''}>
            <input
              type="radio"
              name="mode"
              checked={mode === 'existing'}
              onChange={() => setMode('existing')}
            />
            Use existing pipeline
          </label>
        </div>
        {mode === 'existing' && (
          <div className="field">
            <label htmlFor="existing">Existing pipeline</label>
            <select id="existing" value={existing} onChange={(e) => void chooseExisting(e.target.value)}>
              <option value="">— select a pipeline —</option>
              {(pipelines.data ?? []).map((p) => (
                <option key={p}>{p}</option>
              ))}
            </select>
          </div>
        )}
      </Section>

      <Section title="Dataset" hint="The data your team will inspect for errors.">
        <select hidden id="dataset" aria-label="Dataset" value={activeDataset} onChange={(e) => setDataset(e.target.value)}>
          {datasetList.map((d) => (
            <option key={d}>{d}</option>
          ))}
        </select>
        <div className="cfg-tiles" role="radiogroup" aria-label="Choose dataset">
          {datasetList.map((d) => (
            <button
              key={d}
              type="button"
              role="radio"
              aria-checked={d === activeDataset}
              className={`cfg-tile${d === activeDataset ? ' on' : ''}`}
              onClick={() => setDataset(d)}
            >
              <span className="cfg-tile-icon"><DbIcon /></span>
              <span className="cfg-tile-name">{d}</span>
              <span className="cfg-tile-check"><CheckIcon /></span>
            </button>
          ))}
        </div>
        {datasets.isLoading && <Loading className="cfg-muted">Loading datasets…</Loading>}

        <h3 className="cfg-sub">Tables</h3>
        {tables.isError && <Notice kind="error">{(tables.error as Error).message}</Notice>}
        {tables.data && tables.data.length === 0 && (
          <Notice kind="info">No tables found in this dataset.</Notice>
        )}
        {tables.data && tables.data.length > 0 && (
          <ul className="tables cfg-chips">
            {tables.data.map((t) => (
              <li key={t}>
                <button type="button" className="link" onClick={() => setOpenTable(t)}>
                  <TableIcon />
                  {t}
                </button>
              </li>
            ))}
          </ul>
        )}
      </Section>

      <Section title="Labeling budget" hint="How many cells each player labels, from 1 to 100.">
        <div className="cfg-budget">
          <BudgetField value={budget} onChange={setBudget} />
        </div>
      </Section>

      <Section title="Error detection strategies" hint="Detectors that propose suspicious cells. Turn off any you do not want.">
        <div className="cfg-strategies">
          <StrategyChecklist
            strategies={strategies.data ?? []}
            selected={selected}
            onChange={setChosen}
            error={strategies.isError}
            loading={strategies.isLoading}
          />
        </div>
      </Section>

      {mode === 'new' && (
        <Section title="Pipeline name" hint="Your session suffix is added automatically.">
          <div className="field">
            <input
              id="pipeline-name"
              aria-label="Pipeline name"
              aria-invalid={nameTaken || undefined}
              value={name}
              onChange={(e) => setTypedName(e.target.value)}
            />
          </div>
          {nameTaken && (
            <Notice kind="warn">A pipeline with that name already exists. Please choose a different name.</Notice>
          )}
        </Section>
      )}
      {mode === 'existing' && existing && (
        <Section title="Save as (optional)">
          <div className="field">
            <label htmlFor="save-as">Save as</label>
            <input
              id="save-as"
              value={saveAs}
              placeholder={existing}
              onChange={(e) => setSaveAs(e.target.value)}
            />
          </div>
          <p className="cfg-muted">Leave blank to overwrite this pipeline. A different name makes a copy and keeps its results.</p>
        </Section>
      )}

      {error && <Notice kind="error">{error}</Notice>}

      {openTable && activeDataset && (
        <TableModal dataset={activeDataset} table={openTable} onClose={() => setOpenTable(null)} />
      )}

      <div className="cfg-bar">
        <Link className="btn btn-ghost" to="/lobby">
          Back
        </Link>
        <span className="cfg-hint" aria-live="polite">{blockerText}</span>
        <Button loading={saving} disabled={!canSave} onClick={() => void save()}>
          Continue
        </Button>
      </div>
    </div>
  )
}

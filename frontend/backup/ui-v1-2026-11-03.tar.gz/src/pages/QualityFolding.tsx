import { useQuery, useQueryClient } from '@tanstack/react-query'
import { useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { DataTable } from '../components/DataTable'
import { CutButton, DomainBox, DragGhost, FoldBox, Modal, useDragController } from '../components/foldBoard'
import type { DragController } from '../components/foldBoard'
import { BudgetField, StrategyChecklist } from '../components/forms'
import { Button, Card, InfoButton, JobStatus, Notice } from '../components/ui'
import { useJob } from '../jobs/useJob'
import {
  fetchCellFolds,
  fetchDirtyPage,
  fetchFoldCells,
  fetchPipeline,
  fetchStrategies,
  mergeCellFolds,
  moveCell,
  moveFoldToDomain,
  setFoldLabel,
  splitCellFold,
  splitDomain,
  startQualityFolding,
} from '../lib/api'
import type { CellRef, CellView, FoldSummary } from '../lib/api'
import { useSession } from '../session/SessionProvider'
import '../styles/pages/quality-folding.css'

const PAGE = 10

/** The domain is shown once on its rectangle, so inside it a fold is just "Cell Fold 0". */
const tailOf = (f: FoldSummary) => (f.name.includes(' / ') ? f.name.slice(f.name.lastIndexOf(' / ') + 3) : f.name)
/** A fold moved in from another domain keeps its full name when its short name would clash with a neighbour. */
const shortName = (f: FoldSummary, siblings: FoldSummary[]) =>
  siblings.some((o) => o !== f && tailOf(o) === tailOf(f)) ? f.name : tailOf(f)

/** What a chip shows: just the value; its origin (table, column, row) is in the details popup. */
const valueOf = (c: CellView) => (c.val === null || c.val === undefined || c.val === '' ? '(empty)' : String(c.val))

const refOf = (c: CellRef | CellView): CellRef => ({ table: c.table, row: c.row, col: c.col })

function FoldCells({
  pipeline,
  fold,
  cellCount,
  dnd,
  onCut,
  onOpen,
}: {
  pipeline: string
  fold: string
  cellCount: number
  dnd: DragController
  onCut: (cell: CellView) => void
  onOpen: (cell: CellView) => void
}) {
  const [cells, setCells] = useState<CellView[]>([])
  const [total, setTotal] = useState(0)
  const [error, setError] = useState('')
  const loaded = useRef(0)
  loaded.current = cells.length

  // Load the first page, and reload (quietly, the old cells stay on screen) whenever the fold's size changes,
  // i.e. after a cell was moved in or out. Cells already shown with "Show more" are kept.
  useEffect(() => {
    let current = true
    const limit = Math.min(200, Math.max(PAGE, loaded.current))
    fetchFoldCells(pipeline, fold, 0, limit)
      .then((page) => {
        if (!current) return
        setCells(page.cells)
        setTotal(page.total)
        setError('')
      })
      .catch((e) => current && setError(e instanceof Error ? e.message : 'Could not load the cells'))
    return () => {
      current = false
    }
  }, [pipeline, fold, cellCount])

  const totalRef = useRef(0)
  totalRef.current = total
  const loading = useRef(false)
  const list = useRef<HTMLUListElement | null>(null)

  // No "show more" button: the next page loads by itself when the list is scrolled near its end.
  const more = async () => {
    if (loading.current || loaded.current >= totalRef.current) return
    loading.current = true
    try {
      const page = await fetchFoldCells(pipeline, fold, loaded.current, PAGE)
      setCells((prev) => [...prev, ...page.cells])
      setTotal(page.total)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not load the cells')
    } finally {
      loading.current = false
    }
  }
  const nearEnd = (el: HTMLElement) => el.scrollHeight > 0 && el.scrollTop + el.clientHeight >= el.scrollHeight - 60

  return (
    <div>
      {error && <Notice kind="error">{error}</Notice>}
      <ul
        className="chips scroll"
        ref={list}
        onScroll={(e) => nearEnd(e.currentTarget) && void more()}
      >
        {cells.map((cell, i) => (
          <li key={`${cell.table}|${cell.row}|${cell.col}`}>
            <button
              type="button"
              className="chip"
              data-testid="cell"
              title="Click for details"
              {...dnd.source({ kind: 'item', fold, item: cell }, valueOf(cell))}
              onClick={() => onOpen(cell)}
            >
              {valueOf(cell)}
            </button>
            {i < total - 1 && (
              <CutButton
                label={`Split ${fold} after ${cell.table} ${cell.row} ${cell.col}`}
                onCut={() => onCut(cell)}
              />
            )}
          </li>
        ))}
        {cells.length < total && (
          <li className="more-row" aria-hidden="true">
            {`scroll for ${total - cells.length} more`}
          </li>
        )}
      </ul>
    </div>
  )
}

function CellDialog({
  dataset,
  cell,
  onClose,
}: {
  dataset: string
  cell: CellView
  onClose: () => void
}) {
  const start = Math.max(0, cell.row - 5)
  const excerpt = useQuery({
    queryKey: ['excerpt', dataset, cell.table, start],
    queryFn: () => fetchDirtyPage(dataset, cell.table, start, 11),
  })
  const data = excerpt.data
  const diff = data
    ? data.rows.map((_, r) => data.columns.map((c) => start + r === cell.row && c === cell.col))
    : undefined
  return (
    <Modal label="Cell details" onClose={onClose}>
      <h2>{`Details for ${valueOf(cell)}`}</h2>
      <dl className="origin">
        <dt>Value</dt>
        <dd>{valueOf(cell)}</dd>
        <dt>Table</dt>
        <dd>
          <code>{cell.table}</code>
        </dd>
        <dt>Column</dt>
        <dd>
          <code>{cell.col}</code>
        </dd>
        <dt>Row</dt>
        <dd>{cell.row}</dd>
      </dl>
      <h3>Error detection results</h3>
      {cell.strategies.length > 0 ? (
        <ul>
          {cell.strategies.map((s) => (
            <li key={s}>{s}</li>
          ))}
        </ul>
      ) : (
        <p>This cell passed all error detection checks.</p>
      )}
      <h3>Table excerpt</h3>
      {excerpt.isError && <Notice kind="error">{(excerpt.error as Error).message}</Notice>}
      {data && <DataTable columns={data.columns} rows={data.rows} diff={diff} highlight="dirty" />}
      <Button variant="ghost" onClick={onClose}>
        Close
      </Button>
    </Modal>
  )
}

export function QualityFolding({ pollMs = 1000 }: { pollMs?: number }) {
  const session = useSession()
  const queryClient = useQueryClient()
  const pipeline = session.data.pipeline_path as string | undefined

  const config = useQuery({
    queryKey: ['pipeline', pipeline],
    queryFn: () => fetchPipeline(pipeline as string),
    enabled: !!pipeline,
  })
  const strategies = useQuery({ queryKey: ['strategies'], queryFn: fetchStrategies })
  const hasDomainFolds = !!config.data && Object.keys((config.data.domain_folds as object) ?? {}).length > 0
  const cellFolds = useQuery({
    queryKey: ['cellFolds', pipeline],
    queryFn: () => fetchCellFolds(pipeline as string),
    enabled: !!pipeline && config.data?.has_cell_folds === true,
  })

  const [budget, setBudget] = useState<number | null>(null)
  const [chosen, setChosen] = useState<string[] | null>(null)
  const effectiveBudget = budget ?? config.data?.labeling_budget ?? 10
  const selected = chosen ?? config.data?.selected_strategies ?? []

  const [jobId, setJobId] = useState<string | null>(null)
  const job = useJob(jobId, pollMs)
  const handled = useRef<string | null>(null)
  useEffect(() => {
    if (job.state === 'done' && jobId && handled.current !== jobId) {
      handled.current = jobId
      void queryClient.invalidateQueries({ queryKey: ['pipeline', pipeline] })
      void queryClient.invalidateQueries({ queryKey: ['cellFolds', pipeline] })
      setVersion((v) => v + 1)
    }
  }, [job.state, jobId, pipeline, queryClient])

  const dnd = useDragController()
  const saving = useRef(false)
  const [open, setOpen] = useState<CellView | null>(null)
  const [version, setVersion] = useState(0)
  const [error, setError] = useState('')

  if (!session.ready) return <div className="quality-page"><h1>Quality Folding</h1></div>
  if (!pipeline) {
    return (
      <div className="quality-page">
        <h1>Quality Folding</h1>
        <Notice kind="warn">Pipeline not configured.</Notice>
        <Link to="/configuration">Go back to Configurations</Link>
      </div>
    )
  }
  if (config.data && !hasDomainFolds) {
    return (
      <div className="quality-page">
        <h1>Quality Folding</h1>
        <Notice kind="warn">Run domain based folding first.</Notice>
        <Link to="/domain-folding">Go to Domain Folding</Link>
      </div>
    )
  }

  const edit = async (fn: () => Promise<FoldSummary[]>): Promise<boolean> => {
    if (saving.current) return false // a change is still on its way: the folds on screen may be outdated
    saving.current = true
    setError('')
    try {
      // the server answers with the new folds, so show them at once instead of waiting for a refetch
      queryClient.setQueryData(['cellFolds', pipeline], await fn())
      return true
    } catch (e) {
      setError(e instanceof Error ? e.message : 'The change could not be saved')
      await queryClient.invalidateQueries({ queryKey: ['cellFolds', pipeline] }) // show what the server really has
      return false
    } finally {
      saving.current = false
    }
  }

  const run = async () => {
    setError('')
    try {
      setJobId(
        await startQualityFolding(pipeline, {
          labeling_budget: effectiveBudget,
          selected_strategies: selected,
        }),
      )
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not start quality folding')
    }
  }

  const folds: FoldSummary[] = cellFolds.data ?? []
  const domains = [...new Set(folds.map((f) => f.domain))]
  const byDomain = Object.fromEntries(domains.map((d) => [d, folds.filter((f) => f.domain === d)]))

  return (
    <div className="quality-page">
      <header className="qp-head">
        <div className="title-row">
          <h1>Quality Folding</h1>
        <InfoButton label="How to edit the folds">
          Drag a cell onto a fold to move it · drag ⠿ onto a fold to merge, onto a domain to move the fold there · ✂ between
          cells splits a fold, ✂ in a fold's header splits its domain · click a cell for details · ✓ / ✗ mark a whole fold,
          ↩ takes the mark back
        </InfoButton>
        </div>
        <p className="qp-lede">
          Group cells with similar error behavior into folds, so each label you give teaches the detector about many cells at once.
        </p>
      </header>

      <Card title="Settings">
        <BudgetField value={effectiveBudget} onChange={setBudget} />
        <StrategyChecklist
          strategies={strategies.data ?? []}
          selected={selected}
          onChange={setChosen}
          error={strategies.isError}
          loading={strategies.isLoading}
        />
        <Button
          onClick={() => void run()}
          loading={job.state === 'running'}
          disabled={selected.length === 0 || !config.data}
        >
          Run quality based folding
        </Button>
        <JobStatus state={job.state} error={job.error} />
      </Card>

      {cellFolds.isError && <Notice kind="error">{(cellFolds.error as Error).message}</Notice>}
      {config.data && config.data.has_cell_folds !== true && (
        <Notice kind="info">No cell folds yet. Run quality based folding to create them.</Notice>
      )}

      {folds.length > 0 && (
        <>
          <div className="domain-grid">
          {domains.map((domain) => (
            <DomainBox
              key={domain}
              name={domain}
              dnd={dnd}
              onDropFold={(fold) => void edit(() => moveFoldToDomain(pipeline, fold, domain))}
            >
              <h2>{domain}</h2>
              <div className="fold-grid inner">
              {byDomain[domain].map((fold, index) => (
                  <FoldBox<CellView>
                    key={fold.name}
                    name={fold.name}
                    domain={domain}
                    dnd={dnd}
                    onDropItem={(cell) => void edit(() => moveCell(pipeline, refOf(cell), fold.name))}
                    onMergeFold={(source) => void edit(() => mergeCellFolds(pipeline, [fold.name, source]))}
                    header={
                      <>
                        <span className={`fold-name label-${fold.label}`}>{shortName(fold, byDomain[domain])}</span>
                        <span>{`${fold.cell_count} cells`}</span>
                        {index < byDomain[domain].length - 1 && (
                          <span className="head-end">
                            <CutButton
                              label={`Split domain ${domain} after ${fold.name}`}
                              title="Split domain here: the folds after this one move to a new domain"
                              onCut={() => void edit(() => splitDomain(pipeline, domain, fold.name))}
                            />
                          </span>
                        )}
                        <span className="fold-marks">
                          <Button
                            variant="ghost"
                            aria-label={`Mark ${fold.name} correct`}
                            title="Mark the whole fold correct"
                            onClick={() => void edit(() => setFoldLabel(pipeline, fold.name, 'correct'))}
                          >
                            ✓
                          </Button>
                          <Button
                            variant="ghost"
                            aria-label={`Mark ${fold.name} false`}
                            title="Mark the whole fold as errors"
                            onClick={() => void edit(() => setFoldLabel(pipeline, fold.name, 'false'))}
                          >
                            ✗
                          </Button>
                          <Button
                            variant="ghost"
                            aria-label={`Clear label of ${fold.name}`}
                            title="Take the mark back"
                            disabled={!fold.label}
                            onClick={() => void edit(() => setFoldLabel(pipeline, fold.name, null))}
                          >
                            ↩
                          </Button>
                        </span>
                      </>
                    }
                  >
                    <FoldCells
                      key={`${fold.name}-${version}`}
                      pipeline={pipeline}
                      fold={fold.name}
                      cellCount={fold.cell_count}
                      dnd={dnd}
                      onCut={(cell) => void edit(() => splitCellFold(pipeline, fold.name, [refOf(cell)]))}
                      onOpen={setOpen}
                    />
                  </FoldBox>
                ))}
              </div>
            </DomainBox>
          ))}
          </div>
        </>
      )}

      <DragGhost dnd={dnd} />

      {open && config.data && (
        <CellDialog dataset={config.data.selected_dataset} cell={open} onClose={() => setOpen(null)} />
      )}

      {error && <Notice kind="error">{error}</Notice>}

      <div className="nav-row">
        <Link className="btn btn-ghost" to="/domain-folding">
          Back
        </Link>
        <Link className="btn btn-primary" to="/labeling">
          Continue
        </Link>
      </div>
    </div>
  )
}

import { useQuery } from '@tanstack/react-query'
import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Modal } from '../components/foldBoard'
import { Button, Card, Loading, Notice } from '../components/ui'
import { fetchPropagation } from '../lib/api'
import { useSession } from '../session/SessionProvider'
import '../styles/pages/propagated-errors.css'

const PAGE = 20

interface Propagated {
  table?: string
  row?: number
  col?: string
  val?: unknown
  confidence?: number
  reason?: string
}
interface Labeled {
  table?: string
  row?: number
  col?: string
  val?: unknown
  is_error?: boolean
  domain_fold?: string
  cell_fold?: string
  propagated_cells?: Propagated[]
}

function VerdictBadge({ error }: { error?: boolean }) {
  return (
    <span className={`pe-badge ${error ? 'is-error' : 'is-ok'}`}>
      <svg viewBox="0 0 16 16" width="12" height="12" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        {error ? <path d="M4 4l8 8M12 4l-8 8" /> : <path d="M3 8.5l3.2 3.2L13 4.8" />}
      </svg>
      {error ? 'Error' : 'Correct'}
    </span>
  )
}

function LabeledRow({ cell }: { cell: Labeled }) {
  const [open, setOpen] = useState(false)
  const n = cell.propagated_cells?.length ?? 0
  return (
    <li className="pe-item">
      <button type="button" className="pe-cell" aria-haspopup="dialog" onClick={() => setOpen(true)}>
        <VerdictBadge error={cell.is_error} />
        <span className="pe-cell-main">
          <span className="pe-cell-val">{`Cell: ${String(cell.val ?? 'Unknown Value')}`}</span>
          <span className="pe-cell-sub">{[cell.table, cell.col, cell.row !== undefined ? `row ${cell.row}` : null].filter(Boolean).join(' · ')}</span>
        </span>
        <span className="pe-count">{n > 0 ? `${n} propagated` : 'none propagated'}</span>
        <svg className="pe-chev" viewBox="0 0 16 16" width="16" height="16" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M6 3l5 5-5 5" />
        </svg>
      </button>
      {open && (
        <Modal label="Labeled cell details" onClose={() => setOpen(false)}>
          <div className="propagated-page pe-modal">
          <h2 className="pe-modal-title">
            <VerdictBadge error={cell.is_error} />
            {`Cell: ${String(cell.val ?? 'Unknown Value')}`}
          </h2>
          <dl className="origin">
            {cell.table && (
              <>
                <dt>Table</dt>
                <dd>
                  <code>{cell.table}</code>
                </dd>
              </>
            )}
            {cell.col && (
              <>
                <dt>Column</dt>
                <dd>
                  <code>{cell.col}</code>
                </dd>
              </>
            )}
            {cell.row !== undefined && (
              <>
                <dt>Row</dt>
                <dd>{cell.row}</dd>
              </>
            )}
            {cell.domain_fold && (
              <>
                <dt>Domain fold</dt>
                <dd>{cell.domain_fold}</dd>
              </>
            )}
            {cell.cell_fold && (
              <>
                <dt>Cell fold</dt>
                <dd>{cell.cell_fold}</dd>
              </>
            )}
          </dl>
          {cell.propagated_cells && cell.propagated_cells.length > 0 ? (
            <>
              <h3>{`Propagated to ${cell.propagated_cells.length} cell${cell.propagated_cells.length === 1 ? '' : 's'}`}</h3>
              <div className="pe-table-wrap">
              <table className="propagated">
                <thead>
                  <tr>
                    <th>Table</th>
                    <th>Row</th>
                    <th>Column</th>
                    <th>Value</th>
                    <th>Confidence</th>
                    <th>Reason</th>
                  </tr>
                </thead>
                <tbody>
                  {cell.propagated_cells.map((p, i) => (
                    <tr key={i}>
                      <td>{p.table ?? 'Unknown'}</td>
                      <td>{p.row ?? '?'}</td>
                      <td>{p.col ?? '?'}</td>
                      <td>{String(p.val ?? '')}</td>
                      <td>
                        <span className="pill pe-conf" aria-label={`Confidence: ${Math.round((p.confidence ?? 0) * 100)}%`}>
                          {`${Math.round((p.confidence ?? 0) * 100)}%`}
                        </span>
                      </td>
                      <td>{p.reason ?? ''}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              </div>
            </>
          ) : (
            <p>No cells were propagated from this label</p>
          )}
          <Button variant="ghost" onClick={() => setOpen(false)}>
            Close
          </Button>
          </div>
        </Modal>
      )}
    </li>
  )
}

export function PropagatedErrors() {
  const session = useSession()
  const pipeline = session.data.pipeline_path as string | undefined
  const [offset, setOffset] = useState(0)
  const results = useQuery({
    queryKey: ['propagation', pipeline, offset],
    queryFn: () => fetchPropagation(pipeline as string, offset, PAGE),
    enabled: !!pipeline,
  })

  const head = (
    <header className="pe-head">
      <h1>Propagated Errors</h1>
      <p className="pe-lead">See how each label you gave spread to similar cells across your tables.</p>
    </header>
  )
  if (!session.ready) return <div className="propagated-page">{head}</div>
  if (!pipeline) {
    return (
      <div className="propagated-page">
        {head}
        <Notice kind="warn">Pipeline not configured.</Notice>
        <Link className="pe-link" to="/configuration">Go back to Configurations</Link>
      </div>
    )
  }
  const notYet = results.isError && /label propagation first/i.test((results.error as Error).message)

  return (
    <div className="propagated-page">
      {head}
      {results.isPending && <Loading className="pe-loading">Loading results…</Loading>}
      {notYet && (
        <>
          <Notice kind="info">Run label propagation first: finish the labeling step and press Continue.</Notice>
          <Link className="pe-link" to="/labeling">Go to Labeling</Link>
        </>
      )}
      {results.isError && !notYet && <Notice kind="error">{(results.error as Error).message}</Notice>}
      {results.data && (
        <>
          <div className="stats pe-stats">
            <div className="stat">
              <span>Labeled cells</span>
              <b>{results.data.total}</b>
            </div>
            <div className="stat">
              <span>Propagated labels</span>
              <b>{results.data.propagated_total}</b>
            </div>
          </div>
          <Card>
            <p className="pe-intro">Below are the cells that were labeled and how their labels were propagated to other cells.</p>
            {results.data.labeled_cells.length === 0 && <p className="pe-empty">No labeled cells yet.</p>}
            <ul className="pe-list">
              {(results.data.labeled_cells as Labeled[]).map((cell, i) => (
                <LabeledRow key={`${offset}-${i}`} cell={cell} />
              ))}
            </ul>
            <div className="pager">
              <button disabled={offset === 0} onClick={() => setOffset(Math.max(0, offset - PAGE))}>
                Previous page
              </button>
              <span>{`${offset + 1}–${Math.min(offset + PAGE, results.data.total)} of ${results.data.total}`}</span>
              <button disabled={offset + PAGE >= results.data.total} onClick={() => setOffset(offset + PAGE)}>
                Next page
              </button>
            </div>
          </Card>
        </>
      )}
      <div className="nav-row">
        <Link className="btn btn-ghost" to="/labeling">
          Back
        </Link>
        <Link className="btn btn-primary" to="/error-detection">
          Continue
        </Link>
      </div>
    </div>
  )
}

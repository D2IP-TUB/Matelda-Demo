import { useQuery } from '@tanstack/react-query'
import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import '../styles/pages/labeling-stats.css'
import { DataTable } from '../components/DataTable'
import { Stat } from '../components/stats'
import { Loading, Notice } from '../components/ui'
import { fetchLabelAccuracy } from '../lib/api'
import { pb } from '../lib/pb'
import { RoomService } from '../rooms/roomService'
import { useSession } from '../session/SessionProvider'

const PAGE = 100

function Accuracy({ pipeline }: { pipeline: string }) {
  const [offset, setOffset] = useState(0)
  const accuracy = useQuery({
    queryKey: ['accuracy', pipeline, offset],
    queryFn: () => fetchLabelAccuracy(pipeline, offset, PAGE),
  })
  if (accuracy.isError) return <Notice kind="warn">{(accuracy.error as Error).message}</Notice>
  if (!accuracy.data) return <Loading>Loading…</Loading>
  const d = accuracy.data
  return (
    <>
      <div className="stats">
        <Stat label="Total cells labeled" value={String(d.total)} />
        <Stat label="Correct labels" value={String(d.correct)} />
        <Stat label="Your accuracy" value={`${(d.accuracy * 100).toFixed(1)}%`} />
      </div>
      <DataTable
        columns={['Table', 'Row', 'Column', 'Value', 'You said', 'Truth', 'Clean value', 'Correct']}
        rows={d.rows.map((r) => [
          String(r.table), String(r.row), String(r.col), String(r.val),
          r.user_said_error ? 'error' : 'correct', r.truth_is_error ? 'error' : 'correct',
          String(r.clean_value), r.correct ? '✓ Correct' : '✗ Wrong',
        ])}
        rowClassName={(i) => (d.rows[i].correct ? 'row-right' : 'row-wrong')}
      />
      <div className="pager">
        <button disabled={offset === 0} onClick={() => setOffset(Math.max(0, offset - PAGE))}>
          Previous page
        </button>
        <span>{`${d.total === 0 ? 0 : offset + 1}–${Math.min(offset + PAGE, d.total)} of ${d.total}`}</span>
        <button disabled={offset + PAGE >= d.total} onClick={() => setOffset(offset + PAGE)}>
          Next page
        </button>
      </div>
    </>
  )
}

const initials = (n: string) => n.split(/\s+/).map((w) => w[0]).join('').slice(0, 2).toUpperCase()

/** Shown after labeling: how you did, and how the whole room did. Leads on to label propagation. */
export function LabelingStats({ roomService }: { roomService?: RoomService }) {
  const session = useSession()
  const service = useMemo(() => roomService ?? new RoomService(pb), [roomService])
  const pipeline = session.data.pipeline_path as string | undefined
  const roomName = session.data.room_name as string | undefined
  const token = session.data.player_token as string | undefined
  const disputed = (session.data.room_disputed_cells as string[] | undefined) ?? []

  const roomCtx = useQuery({
    queryKey: ['room-context', roomName, token],
    enabled: session.ready && !!roomName && !!token,
    queryFn: async () => {
      const room = await service.getRoom(roomName as string)
      const player = room ? await service.getPlayer(roomName as string, token as string) : null
      return room && player ? { room, player } : null
    },
  })
  const inRoom = roomCtx.data ?? null
  const stats = useQuery({
    queryKey: ['room-stats', inRoom?.room.name],
    queryFn: () => service.playerStats(inRoom!.room.name),
    enabled: !!inRoom,
  })

  const head = (
    <header>
      <h1>Labeling Stats</h1>
      <p className="ls-lead">How your labels compare with the truth, and how the room did.</p>
    </header>
  )
  if (!session.ready) return <div className="lstats-page">{head}</div>
  if (!pipeline) {
    return (
      <div className="lstats-page">
        {head}
        <Notice kind="warn">Pipeline not configured.</Notice>
        <Link to="/configuration">Go back to Configurations</Link>
      </div>
    )
  }

  const roomStats = stats.data ?? []
  const totalLabels = roomStats.reduce((n, s) => n + s.labels, 0)
  const totalCorrect = roomStats.reduce((n, s) => n + s.correct, 0)
  const ranked = [...roomStats].sort((a, b) => b.accuracy - a.accuracy || b.labels - a.labels)

  return (
    <div className="lstats-page">
      {head}
      {inRoom && (
        <section>
          <h2>Room labeling</h2>
          {roomStats.length === 0 ? (
            <p>{`Room ${inRoom.room.name} has no labels yet.`}</p>
          ) : (
            <>
              <div className="stats">
                <Stat label="Labels in the room" value={String(totalLabels)} />
                <Stat label="Labelers" value={String(roomStats.length)} />
                <Stat label="Room accuracy" value={`${((100 * totalCorrect) / totalLabels).toFixed(0)}%`} />
              </div>
              <ol className="rank" aria-label="Leaderboard by accuracy">
                {ranked.map((s, i) => (
                  <li key={s.id} className={s.id === inRoom.player.id ? 'me' : undefined}>
                    <span className="rank-n">{i + 1}</span>
                    <span className="avatar" aria-hidden="true">{initials(s.name)}</span>
                    <span className="rank-name">
                      {s.name}
                      {s.id === inRoom.player.id && <em className="you">You</em>}
                    </span>
                    <span className="rank-bar" aria-hidden="true"><i style={{ width: `${Math.round(100 * s.accuracy)}%` }} /></span>
                    <b className="rank-acc">{`${(100 * s.accuracy).toFixed(0)}% · ${s.labels} labels`}</b>
                  </li>
                ))}
              </ol>
              {disputed.length > 0 && (
                <Notice kind="info">
                  {`${disputed.length} disputed cell(s) (players disagreed 50/50) were left out of your run.`}
                </Notice>
              )}
            </>
          )}
        </section>
      )}

      <h2>Label Analysis</h2>
      <Accuracy pipeline={pipeline} />

      <div className="nav-row">
        <Link className="btn btn-ghost" to="/labeling">
          Back
        </Link>
        <Link className="btn btn-primary" to="/propagated-errors">
          Continue
        </Link>
      </div>
    </div>
  )
}

import '../styles/pages/lobby.css'
import { useEffect, useMemo, useRef, useState } from 'react'
import { JoinQr } from '../components/JoinQr'
import { Link, useSearchParams } from 'react-router-dom'
import { pb } from '../lib/pb'
import { RoomService } from '../rooms/roomService'
import type { Player } from '../rooms/roomService'
import { NOTICE_KEY, resetSession, useRoomInfo } from '../rooms/useRoomInfo'
import { Button, Loading } from '../components/ui'
import { useSession } from '../session/SessionProvider'

interface LobbyProps {
  roomService?: RoomService
}

export function Lobby({ roomService }: LobbyProps) {
  const service = useMemo(() => roomService ?? new RoomService(pb), [roomService])
  const session = useSession()
  const [params, setParams] = useSearchParams()
  const roomName = params.get('room') ?? (session.data.room_name as string | undefined)

  const [status, setStatus] = useState<'idle' | 'loading' | 'notfound' | 'ended' | 'ready'>('idle')
  const [message, setMessage] = useState('')
  const [creating, setCreating] = useState(false)
  const [starting, setStarting] = useState(false)
  const [joinInput, setJoinInput] = useState('')
  const entered = useRef<string | null>(null)
  const info = useRoomInfo(service)
  const { room, me, players, isHost, leave: leaveOldRoom } = info

  // Enter (create the player in) the room named in the URL or stored in the session.
  useEffect(() => {
    if (!roomName) entered.current = null
    if (!session.ready || !roomName || entered.current === roomName) return
    entered.current = roomName
    const stored = session.data.room_name as string | undefined
    const token = stored === roomName ? (session.data.player_token as string | undefined) : undefined
    setStatus('loading')
    setMessage('')
    ;(async () => {
      try {
        const found = await service.getRoom(roomName)
        if (!found) {
          setStatus('notfound')
          return
        }
        if (found.phase === 'ended') {
          setStatus('ended')
          return
        }
        if (stored && stored !== roomName) await leaveOldRoom()
        if (token && !(await service.getPlayer(roomName, token))) {
          // Kicked while away: the stored token no longer has a player. Never re-admit.
          await resetSession(session, 'removed')
          setStatus('idle')
          if (params.get('room')) setParams({})
          return
        }
        const player = await service.joinRoom(roomName, token)
        await service.claimHost(found, player)
        await session.update({ room_name: roomName, player_token: player.token })
        await session.remove([NOTICE_KEY])
        setStatus('ready')
      } catch (e) {
        entered.current = null
        setStatus('idle')
        setMessage(e instanceof Error ? e.message : 'Could not join the room')
      }
    })()
  }, [session, roomName, service, leaveOldRoom, params, setParams])

  // Left, kicked or the session ended: back to the create/join view.
  useEffect(() => {
    if (status === 'ready' && !info.roomName) {
      setStatus('idle')
      if (params.get('room')) setParams({})
    }
  }, [status, info.roomName, params, setParams])

  const create = async () => {
    setCreating(true)
    try {
      const created = await service.createRoom()
      setParams({ room: created.name })
    } catch (e) {
      setMessage(e instanceof Error ? e.message : 'Could not create a room')
    } finally {
      setCreating(false)
    }
  }

  const start = async () => {
    if (!room) return
    setStarting(true)
    try {
      await service.startRoom(room)
      await info.refresh()
      setMessage('')
    } catch (e) {
      setMessage(e instanceof Error ? e.message : 'Could not start')
    } finally {
      setStarting(false)
    }
  }

  const kick = async (target: Player) => {
    if (!room || !me) return
    try {
      await service.kickPlayer(room, me.id, target)
      await info.refresh()
    } catch (e) {
      setMessage(e instanceof Error ? e.message : 'Could not remove the player')
    }
  }

  const inRoom = status === 'ready' && room
  const joinUrl = room ? `${window.location.origin}/lobby?room=${room.name}` : ''
  const initial = (n: string) => (n.trim()[0] ?? '?').toUpperCase()

  return (
    <div className="lobby-page">
      <div className="lobby-aurora" aria-hidden="true" />
      <h1 className="lobby-eyebrow">Lobby</h1>
      {!inRoom && (
        <header className="lobby-hero">
          <p className="lobby-headline">Clean data, together.</p>
          <p className="lead">Spot errors side by side with your team. Start a room, share the code, and label in real time.</p>
        </header>
      )}
      {message && <p role="alert" className="lobby-msg lobby-msg-bad">{message}</p>}
      {status === 'notfound' && <p className="lobby-msg lobby-msg-bad">Room not found</p>}
      {status === 'ended' && <p className="lobby-msg lobby-msg-bad">This session has ended</p>}
      {status !== 'ready' && status !== 'loading' && info.notice && (
        <p className="room-notice lobby-msg" role="status">
          {info.notice === 'removed' ? 'You were removed by the host' : 'The host ended the session'}
        </p>
      )}
      {status !== 'loading' && status !== 'ready' && (
        <section className="lobby-start lobby-tiles">
          <div className="lobby-tile lobby-tile-create">
            <span className="lobby-tile-icon" aria-hidden="true">
              <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M12 5v14M5 12h14" /></svg>
            </span>
            <h2>Host a session</h2>
            <p>Open a new room and invite your team with a code or QR.</p>
            <Button className="btn-lg" loading={creating} onClick={() => void create()}>
              Create room
            </Button>
          </div>
          <form
            className="lobby-tile join-form"
            onSubmit={(e) => {
              e.preventDefault()
              if (joinInput.trim()) setParams({ room: joinInput.trim().toLowerCase() })
            }}
          >
            <span className="lobby-tile-icon" aria-hidden="true">
              <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6" /></svg>
            </span>
            <h2>Join with a code</h2>
            <p>Got a room name from a teammate? Enter it here.</p>
            <div className="lobby-join-row">
              <input
                aria-label="Room name"
                placeholder="Room name"
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck={false}
                value={joinInput}
                onChange={(e) => setJoinInput(e.target.value)}
              />
              <button type="submit" className="btn btn-ghost">Join</button>
            </div>
          </form>
        </section>
      )}
      {status === 'loading' || (status === 'ready' && !room) ? <Loading className="lobby-loading">Joining…</Loading> : null}
      {inRoom && room && (
        <section className="lobby-room">
          <div className="lobby-code-card">
            <div className="lobby-code-main">
            <h2>Room <span className="lobby-code">{room.name}</span></h2>
            <p className="lobby-sub">
              <span className="lobby-live" aria-hidden="true" />
              {players.length} {players.length === 1 ? 'player' : 'players'} in the lobby
            </p>
            {room.phase === 'lobby' ? (
              isHost || !room.host ? (
                <Button className="btn-lg" loading={starting} onClick={() => void start()} disabled={!room.host}>
                  Start
                </Button>
              ) : (
                <Loading className="lobby-wait">Waiting for the host to start</Loading>
              )
            ) : (
              <Link className="btn btn-primary btn-lg" to="/configuration">Continue</Link>
            )}
            </div>
            {room.phase === 'lobby' && (
              <div className="lobby-qr">
                <JoinQr url={joinUrl} />
                <p className="lobby-sub">Scan to join</p>
              </div>
            )}
          </div>
          <ul className="players lobby-players">
            {players.map((p) => (
              <li key={p.id} data-testid="player">
                <span className={`lobby-avatar${p.id === room.host ? ' is-host' : ''}`} aria-hidden="true">{initial(p.name)}</span>
                <span className="lobby-pname">
                  {p.name}
                  {p.id === me?.id ? <span className="lobby-tag"> (you)</span> : null}
                  {p.id === room.host ? <span className="lobby-tag lobby-tag-host"> (host)</span> : null}
                </span>
                {isHost && p.id !== me?.id && (
                  <button type="button" className="btn btn-ghost btn-sm lobby-kick" aria-label={`Kick ${p.name}`} onClick={() => void kick(p)}>
                    Kick
                  </button>
                )}
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  )
}
